package edu.uncc.hw10;

public class trips {
    String name, createdAt, completedAt, miles, status, createdBy,id, x, y;

    public trips(String name, String createdAt, String completedAt, String miles, String status, String createdBy, String id, String x, String y) {
        this.name = name;
        this.createdAt = createdAt;
        this.completedAt = completedAt;
        this.miles = miles;
        this.status = status;
        this.createdBy = createdBy;
        this.id = id;
        this.x = x;
        this.y = y;
    }

    public trips(String name, String createdAt, String completedAt, String miles, String status, String createdBy, String id) {
        this.name = name;
        this.createdAt = createdAt;
        this.completedAt = completedAt;
        this.miles = miles;
        this.status = status;
        this.createdBy = createdBy;
        this.id = id;
    }

    public trips(String name, String createdAt, String completedAt, String miles, String status, String createdBy) {
        this.name = name;
        this.createdAt = createdAt;
        this.completedAt = completedAt;
        this.miles = miles;
        this.status = status;
        this.createdBy = createdBy;
    }

    public trips(String name, String createdAt, String completedAt, String miles, String status) {
        this.name = name;
        this.createdAt = createdAt;
        this.completedAt = completedAt;
        this.miles = miles;
        this.status = status;
    }

    public trips() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getCompletedAt() {
        return completedAt;
    }

    public void setCompletedAt(String completedAt) {
        this.completedAt = completedAt;
    }

    public String getMiles() {
        return miles;
    }

    public void setMiles(String miles) {
        this.miles = miles;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getX() {
        return x;
    }

    public void setX(String x) {
        this.x = x;
    }

    public String getY() {
        return y;
    }

    public void setY(String y) {
        this.y = y;
    }
}
