//HW10
//HW10
//Elvis Velasquez, Eduardo Gomez
package edu.uncc.hw10;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity implements loginFragment.LoginListener, createAccountFragment.createListner, tripsFragment.tripsListener, createTripFragment.createTripListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportFragmentManager().beginTransaction()
                .add(R.id.view, new loginFragment())
                .commit();
    }

    @Override
    public void goToCreateAccount() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.view, new createAccountFragment())
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void goTotrips() {

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.view, new tripsFragment())
                .addToBackStack(null)
                .commit();


    }

    @Override
    public void pop() {
        getSupportFragmentManager().popBackStack();
    }

    @Override
    public void goToCreateTrip() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.view, new createTripFragment())
                .addToBackStack(null)
                .commit();

    }

    @Override
    public void goToLogin() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.view, new loginFragment())

                .commit();
    }
}