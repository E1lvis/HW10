package edu.uncc.hw10;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class tripAdapter extends ArrayAdapter<trips> {
    public tripAdapter(@NonNull Context context, int resource, @NonNull List<trips> objects) {
        super(context, resource, objects);
    }
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.trip_item, parent, false);


        }

        TextView name = convertView.findViewById(R.id.name);
        TextView started = convertView.findViewById(R.id.started);
        TextView completed = convertView.findViewById(R.id.completed);
        TextView status = convertView.findViewById(R.id.status);
        TextView miles = convertView.findViewById(R.id.miles);

        trips temp = getItem(position);

        name.setText(temp.getName());
        started.setText("Started At: " + temp.getCreatedAt());
        completed.setText("Completed: " + temp.getCompletedAt());
        status.setText(temp.getStatus());
        miles.setText(temp.getMiles());

        return convertView;
    }

    }
